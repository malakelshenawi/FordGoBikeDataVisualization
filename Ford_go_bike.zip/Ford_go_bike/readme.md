# FordGoBike Data Visualization
## by Malak Elshenawy


## Dataset

> Dataset Ford Go Bike Data can be downloaded from here: https://www.fordgobike.com/system-data This dataset includes information about individual rides made in a bike-sharing system covering different areas. Here we wrangle and explore Ford Go Bike trip data which it makes available for public use. It includes:

Trip Duration (seconds)
Start Time and Date
End Time and Date
Start Station ID
Start Station Name
Start Station Latitude
Start Station Longitude
End Station ID
End Station Name
End Station Latitude
End Station Longitude
Bike ID
User Type
Member Year of Birth
Member Gender

## Summary of Findings

> 
- Environmentally friendly, budget friendly, and lifetsyle friendly.
- Subscribers benefit their health as well as the environment.
- Customers enjoy sight seeing and exploring in a healthy, fun and budget friendly way.
- Bikes are a great way of transportation whether you are going to work, school or simply enjoying the weather and the neighborhood.
